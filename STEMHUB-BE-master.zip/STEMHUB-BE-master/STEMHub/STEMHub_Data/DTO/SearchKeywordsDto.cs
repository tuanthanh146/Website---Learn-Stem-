﻿namespace STEMHub.STEMHub_Data.DTO
{
    public class SearchKeywordsDto
    {
        public string SearchKeyword { get; set; }
        public int SearchCount { get; set; }
    }
}
