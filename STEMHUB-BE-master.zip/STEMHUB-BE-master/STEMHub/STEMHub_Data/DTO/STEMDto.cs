﻿namespace STEMHub.STEMHub_Data.DTO
{
    public class STEMDto
    {
        public Guid STEMId { get; set; }
        public string? STEMName { get; set; }
    }
}
