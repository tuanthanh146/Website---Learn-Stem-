﻿namespace STEMHub.STEMHub_Data.DTO
{
    public class ChatbotRes
    {
        public string Answer { get; set; }
        public bool Found { get; set; }
    }
}
