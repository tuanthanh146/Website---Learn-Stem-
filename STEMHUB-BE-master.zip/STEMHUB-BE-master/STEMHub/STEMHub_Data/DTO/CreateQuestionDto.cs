﻿namespace STEMHub.STEMHub_Data.DTO
{
    public class CreateQuestionDto
    {
        public string Content { get; set; }
        public string Answer { get; set; }
    }
}
