﻿namespace STEMHub.STEMHub_Data.DTO
{
    public class ChatbotReq
    {
        public string Question { get; set; }
    }
}
