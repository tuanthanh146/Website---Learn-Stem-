﻿namespace STEMHub.STEMHub_Data.Entities
{
    public enum CommentType
    {
        Lesson,
        Newspaper,
    }
}
