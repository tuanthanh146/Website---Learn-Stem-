﻿namespace STEMHub.STEMHub_Services.Authentication.Login
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; } = string.Empty;
    }
}
