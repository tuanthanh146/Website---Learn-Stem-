﻿namespace STEMHub.STEMHub_Services.Constants
{
    public static class ResponseMessages
    {
        public static string GetEmailSuccessMessage(string emailAddress) => $"Vui lòng kiểm tra email {emailAddress}.";
    }
}
