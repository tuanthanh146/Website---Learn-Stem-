﻿namespace STEMHub.STEMHub_Services.Constants
{
    public class Response
    {
        public string? Status { get; set; }
        public string? Message { get; set; }
        public bool IsSuccess { get; set; }
    }
}
