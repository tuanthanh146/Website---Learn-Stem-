export { default } from './PostsLayout';
