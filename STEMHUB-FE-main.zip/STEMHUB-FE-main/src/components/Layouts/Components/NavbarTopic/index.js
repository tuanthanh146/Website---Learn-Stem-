export { default } from './NavbarTopic';
