export { default } from './SearchCourseItem';
