export { default } from './FooterLesson';
