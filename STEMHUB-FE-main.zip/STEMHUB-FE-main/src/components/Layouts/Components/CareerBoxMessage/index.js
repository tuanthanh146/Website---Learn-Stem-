export { default } from './CareerBoxMessage';
