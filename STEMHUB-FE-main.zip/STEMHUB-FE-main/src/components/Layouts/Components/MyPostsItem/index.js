export { default } from './MyPostsItem';
