export { default } from './MenuQuestion';
