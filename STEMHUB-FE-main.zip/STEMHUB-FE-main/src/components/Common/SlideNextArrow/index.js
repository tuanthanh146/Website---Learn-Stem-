export { default } from './SlideNextArrow';
