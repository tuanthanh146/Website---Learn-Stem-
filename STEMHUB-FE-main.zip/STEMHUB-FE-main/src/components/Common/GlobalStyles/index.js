export { default } from './GlobalStyles';
