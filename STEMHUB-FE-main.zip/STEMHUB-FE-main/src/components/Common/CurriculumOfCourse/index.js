export { default } from './CurriculumOfCourse';
