export { default } from './FormInput';
