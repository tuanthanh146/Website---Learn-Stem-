export { default } from './SlideShow';
