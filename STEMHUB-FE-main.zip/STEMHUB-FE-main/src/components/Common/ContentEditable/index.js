export { default } from './ContentEditable';
