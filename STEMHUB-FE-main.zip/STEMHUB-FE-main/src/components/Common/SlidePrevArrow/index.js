export { default } from './SlidePrevArrow';
