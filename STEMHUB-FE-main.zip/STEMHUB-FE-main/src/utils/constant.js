const ADMIN = 'Admin';
const USER = 'User';
const URL_FACEBOOK = "https://www.facebook.com/profile.php?id=61567517117031";
const URL_YOUTUBE = "https://www.youtube.com/@STEMV%E1%BA%ADtL%C3%AD-THPT";

export { ADMIN, USER, URL_FACEBOOK, URL_YOUTUBE };
