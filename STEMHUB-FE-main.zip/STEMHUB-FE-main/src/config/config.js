import routes from './routes';
import runGemini from './gemini';

const config = {
    routes,
    runGemini,
};

export default config;
