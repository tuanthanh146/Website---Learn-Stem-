export { default } from './Posts';
