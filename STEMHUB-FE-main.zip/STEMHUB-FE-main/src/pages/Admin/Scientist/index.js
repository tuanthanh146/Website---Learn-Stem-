export { default } from './Scientist';
