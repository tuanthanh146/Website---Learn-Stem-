export { default } from './ForgotPassword';
