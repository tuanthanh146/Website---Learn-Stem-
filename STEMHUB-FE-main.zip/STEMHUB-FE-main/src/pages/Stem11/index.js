export { default } from './Stem11';
