export { default } from './ScientistDetail';
