export { default } from './NewPost';
