export { default } from './Stem10';
