export { default } from './MyPosts';
