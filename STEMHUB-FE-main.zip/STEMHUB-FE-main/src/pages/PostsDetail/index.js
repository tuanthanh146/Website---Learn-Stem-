export { default } from './PostsDetail';
