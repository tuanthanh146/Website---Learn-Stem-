export { default } from './Stem12';
